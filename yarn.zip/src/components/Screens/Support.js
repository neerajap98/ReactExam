import React from 'react'

function Support() {
  return (
    <div>Coming Soon...</div>
  )
}

export default Support