import React from 'react'

function Payment() {
  return (
    <div>Coming Soon...</div>
  )
}

export default Payment