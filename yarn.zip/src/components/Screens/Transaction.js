import React from 'react'

function Transaction() {
  return (
    <div>Coming Soon...</div>
  )
}

export default Transaction