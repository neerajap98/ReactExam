import React from 'react'

function Profile() {
  return (
    <div>Coming Soon...</div>
  )
}

export default Profile;