import React from 'react'

function Settings() {
  return (
    <div>Coming Soon...</div>
  )
}

export default Settings