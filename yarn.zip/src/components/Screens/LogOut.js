import React from 'react'

function LogOut() {
  return (
    <div>Coming Soon...</div>
  )
}

export default LogOut