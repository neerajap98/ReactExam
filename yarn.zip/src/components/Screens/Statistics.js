import React from 'react';

function Statistics() {
  return (
    <div>Coming Soon...</div>
  )
}

export default Statistics;